---
name: dubdub-imagegen
description: Generate raster images from text prompts with the OpenAI-compatible DubDub API and gpt-image-2.5-flare. Use by default whenever the user asks to generate, create, draw, visualize, or make an image, illustration, poster, icon, product render, concept art, or text-to-image variant. Do not use for image-only analysis, format conversion, or uploading an existing image.
---

# DubDub Image Generation

Generate text-to-image assets with the bundled `scripts/generate_image.py` client. The OpenAI-compatible base URL, API key, and model are in the adjacent `config.json` file. Set `base_url` to this site's copyable API address plus `/v1` (for example `https://api.dubdub-ai.cn/v1`). The configured model is `gpt-image-2.5-flare`.

## Workflow

1. Preserve the user's subject, composition, style, text, aspect ratio, and exclusions. Add useful visual detail only where the request leaves room for interpretation.
2. Choose the output path:
   - Use the user's requested path when one is provided.
   - For a project asset, save it in the appropriate project asset directory.
   - For a connectivity check or disposable preview, use the operating system's temporary directory and delete it after verification.
3. Run the script from this Skill directory. On macOS/Linux:

   ```bash
   python3 scripts/generate_image.py \
     --prompt "A precise description of the requested image" \
     --output /absolute/path/to/image.png \
     --size 1024x1024
   ```

   On Windows PowerShell:

   ```powershell
   py -3 .\scripts\generate_image.py --prompt "A precise description of the requested image" --output "C:\path\to\image.png" --size 1024x1024
   ```

4. Read the JSON summary from stdout and verify that every reported file exists and is a valid raster image. Use `view_image` when visual quality or composition matters, then iterate on the prompt if the result misses the user's brief.
5. Return clickable paths for the final images. State the actual pixel dimensions and detected file format; the upstream may return a size different from `--size`. Do not claim visual acceptance when only the API response or file signature was checked.

## Options

- `--size`: OpenAI image size such as `1024x1024`, `1536x1024`, or `1024x1536`. Default: `1024x1024`.
- `--count`: Number of images requested in one API call, from 1 to 4. Default: `1`.
- `--timeout`: Request timeout in seconds. Default: `300`.
- `--check`: Verify authentication, API access, and model availability without generating an image.

When `--count` is greater than one, the script appends `-1`, `-2`, and so on to the output stem. The response may contain fewer images if the upstream model limits batch generation; report the actual files returned.

## Configuration

The Skill reads `config.json` beside `SKILL.md` on macOS and Windows, independent of the current working directory. It contains `base_url` (including `/v1`), `api_key`, and `model`. Update that file when moving the Skill to another computer; each device has its own local copy. The API key is plaintext in this requested configuration file: keep it private and do not put the Skill directory into a shared repository or archive.

Never place the API key in prompts, command arguments, logs, `SKILL.md`, or source files. Do not print `config.json` during troubleshooting. If the file or required fields are missing, report the configuration problem without exposing its contents.

## Boundaries

- This workflow is for text-to-image generation. Do not imply that image editing or reference-image conditioning is supported unless the API is separately verified for that endpoint.
- A successful `--check` proves connectivity and model discovery only. A successful generation requires a valid OpenAI-style response plus a decodable raster file.
- Do not automatically retry an ambiguous failed generation because a timed-out request may still have incurred usage. Explain the failure and let the user decide whether to retry.
