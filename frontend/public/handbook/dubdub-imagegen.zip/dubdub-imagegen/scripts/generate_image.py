#!/usr/bin/env python3
"""通过 DubDub 的 OpenAI 兼容接口生成图片。"""

from __future__ import annotations

import argparse
import base64
import binascii
import json
import os
import re
import struct
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid
from pathlib import Path
from typing import Any


CONFIG_PATH = Path(__file__).resolve().parent.parent / "config.json"
USER_AGENT = "curl/8.7.1"
VALID_SIZE = re.compile(r"^(?:auto|[1-9][0-9]{2,4}x[1-9][0-9]{2,4})$")


class ImageRedirectHandler(urllib.request.HTTPRedirectHandler):
    """处理图片下载跳转；跨域时移除请求中的接口鉴权，返回安全的新请求或 None。"""

    def redirect_request(
        self,
        req: urllib.request.Request,
        fp: Any,
        code: int,
        msg: str,
        headers: Any,
        newurl: str,
    ) -> urllib.request.Request | None:
        """根据原请求和跳转地址创建新请求；仅在同源时保留 Authorization。"""
        redirected = super().redirect_request(req, fp, code, msg, headers, newurl)
        # HTTP 不应接收原本仅发给 HTTPS 接口的令牌，跨主机也必须清除。
        if redirected is not None and (
            urllib.parse.urlsplit(newurl).scheme != "https"
            or urllib.parse.urlsplit(newurl).netloc
            != urllib.parse.urlsplit(req.full_url).netloc
        ):
            redirected.remove_header("Authorization")
        return redirected


def load_config() -> dict[str, str]:
    """读取 Skill 目录的私有 JSON 配置；返回接口地址、密钥和模型，缺失或无效时终止且不输出密钥。"""
    try:
        raw = json.loads(CONFIG_PATH.read_text(encoding="utf-8-sig"))
    except FileNotFoundError as exc:
        raise RuntimeError(f"Missing Skill configuration: {CONFIG_PATH}") from exc
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Invalid JSON in Skill configuration: {CONFIG_PATH}") from exc

    # 配置必须是含有三个非空字符串字段的对象，不接受错误格式的密钥或地址。
    if not isinstance(raw, dict) or any(
        not isinstance(raw.get(field), str) or not raw[field].strip()
        for field in ("base_url", "api_key", "model")
    ):
        raise RuntimeError("Skill configuration requires base_url, api_key, and model")

    base_url = raw["base_url"].strip().rstrip("/")
    parsed = urllib.parse.urlparse(base_url)
    # HTTPS 和明确的 /v1 路径限定为 OpenAI 兼容服务入口，排除含凭据、查询或片段的地址。
    if (
        parsed.scheme != "https"
        or not parsed.netloc
        or parsed.username
        or parsed.password
        or parsed.query
        or parsed.fragment
        or not parsed.path.endswith("/v1")
    ):
        raise RuntimeError("Skill base_url must be an HTTPS OpenAI-compatible /v1 URL")

    return {
        "base_url": base_url,
        "api_key": raw["api_key"].strip(),
        "model": raw["model"].strip(),
    }


def error_message(raw: bytes, status: int) -> str:
    """提取安全的接口错误；输入响应体和状态码，返回不含大块响应或图片数据的消息。"""
    try:
        payload = json.loads(raw.decode("utf-8", errors="replace"))
    except json.JSONDecodeError:
        return f"HTTP {status}: upstream returned a non-JSON error response"

    # OpenAI 兼容错误通常位于 error.message，仅提取该字段避免输出无关或敏感响应。
    if isinstance(payload, dict):
        error = payload.get("error")
        # error 可能是对象，也可能是网关直接返回的字符串。
        if isinstance(error, dict) and isinstance(error.get("message"), str):
            return f"HTTP {status}: {error['message']}"
        # 字符串错误同样可以直接作为简短诊断信息。
        if isinstance(error, str):
            return f"HTTP {status}: {error}"
        # 部分兼容服务把错误说明放在顶层 message 字段。
        if isinstance(payload.get("message"), str):
            return f"HTTP {status}: {payload['message']}"

    return f"HTTP {status}: upstream returned an unrecognized error response"


def request_json(
    url: str,
    api_key: str,
    timeout: int,
    payload: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """调用 JSON 接口；payload 为空时发 GET，否则发 POST，返回对象响应且不自动重试。"""
    data: bytes | None = None
    method = "GET"
    # 生图请求提供 JSON 数据时使用 POST，模型探测保持只读 GET。
    if payload is not None:
        data = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        method = "POST"

    request = urllib.request.Request(
        url,
        data=data,
        method=method,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Accept": "application/json",
            "Content-Type": "application/json",
            "User-Agent": USER_AGENT,
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            raw = response.read()
    except urllib.error.HTTPError as exc:
        raise RuntimeError(error_message(exc.read(8192), exc.code)) from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Network error: {exc.reason}") from exc

    try:
        result = json.loads(raw.decode("utf-8"))
    except json.JSONDecodeError as exc:
        raise RuntimeError("Upstream returned a non-JSON success response") from exc

    # OpenAI 兼容接口的顶层响应必须是对象，其他结构无法安全解析。
    if not isinstance(result, dict):
        raise RuntimeError("Upstream returned an unexpected JSON response")
    return result


def check_connection(config: dict[str, str], timeout: int) -> dict[str, Any]:
    """检查模型连通性；输入接口配置和超时，返回可机器读取的模型存在结果且不产生图片。"""
    endpoint = f"{config['base_url']}/models"
    payload = request_json(endpoint, config["api_key"], timeout)
    data = payload.get("data")
    model_ids: list[str] = []
    # 模型列表缺失时按空列表处理，由 target_model_present 明确反映不可用。
    if isinstance(data, list):
        for item in data:
            # 只读取结构正确的模型 ID，忽略网关附带的其他记录。
            if isinstance(item, dict) and isinstance(item.get("id"), str):
                model_ids.append(item["id"])
    return {
        "ok": config["model"] in model_ids,
        "endpoint": endpoint,
        "model": config["model"],
        "target_model_present": config["model"] in model_ids,
        "model_count": len(model_ids),
    }


def download_image(url: str, config: dict[str, str], timeout: int) -> bytes:
    """下载图片 URL；仅对配置的 HTTPS 同源地址附带鉴权，返回字节且不向外部存储泄露密钥。"""
    parsed = urllib.parse.urlparse(url)
    origin = urllib.parse.urlparse(config["base_url"])
    headers = {"Accept": "image/*", "User-Agent": USER_AGENT}
    # 同源私有图片可能需要鉴权；跨域和非 HTTPS 地址不能收到接口密钥。
    if parsed.scheme == "https" and parsed.netloc == origin.netloc:
        headers["Authorization"] = f"Bearer {config['api_key']}"
    request = urllib.request.Request(url, headers=headers)
    opener = urllib.request.build_opener(ImageRedirectHandler())
    try:
        with opener.open(request, timeout=timeout) as response:
            return response.read()
    except urllib.error.HTTPError as exc:
        raise RuntimeError(f"Image download failed with HTTP {exc.code}") from exc
    except urllib.error.URLError as exc:
        raise RuntimeError(f"Image download failed: {exc.reason}") from exc


def image_bytes(item: dict[str, Any], config: dict[str, str], timeout: int) -> bytes:
    """解析一个 OpenAI 图片条目；支持 b64_json、data URL 和远程 URL，返回图片字节。"""
    encoded = item.get("b64_json")
    # OpenAI GPT Image 默认常以 b64_json 返回图片内容。
    if isinstance(encoded, str) and encoded:
        try:
            return base64.b64decode(encoded, validate=True)
        except (binascii.Error, ValueError) as exc:
            raise RuntimeError("Upstream returned invalid b64_json image data") from exc

    url = item.get("url")
    # 兼容网关把图片内嵌为 data URL 的情况，避免额外网络请求。
    if isinstance(url, str) and url.startswith("data:image/"):
        marker = ";base64,"
        # 只接受明确标记为 base64 的图片 data URL。
        if marker not in url:
            raise RuntimeError("Upstream returned an unsupported image data URL")
        try:
            return base64.b64decode(url.split(marker, 1)[1], validate=True)
        except (binascii.Error, ValueError) as exc:
            raise RuntimeError("Upstream returned invalid image data URL") from exc

    # 普通 URL 由独立下载逻辑处理，并限制密钥只发送到可信同源地址。
    if isinstance(url, str) and url.startswith(("https://", "http://")):
        return download_image(url, config, timeout)

    raise RuntimeError("Image item contains neither b64_json nor a supported URL")


def detect_format(content: bytes) -> tuple[str, str]:
    """识别生成图片格式；输入原始字节，返回格式名和扩展名，未知或非光栅内容会被拒绝。"""
    # PNG 固定使用八字节签名。
    if content.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png", ".png"
    # JPEG 文件以 SOI 标记开头。
    if content.startswith(b"\xff\xd8\xff"):
        return "jpeg", ".jpg"
    # WebP 同时具备 RIFF 容器头和 WEBP 类型标识。
    if len(content) >= 12 and content[:4] == b"RIFF" and content[8:12] == b"WEBP":
        return "webp", ".webp"
    # GIF 允许 87a 与 89a 两种标准签名。
    if content.startswith((b"GIF87a", b"GIF89a")):
        return "gif", ".gif"
    raise RuntimeError("Upstream response is not a recognized raster image")


def image_dimensions(content: bytes, image_format: str) -> tuple[int, int] | None:
    """读取光栅图像头中的真实宽高；无法确定时返回 None，不把请求尺寸误报为结果尺寸。"""
    # PNG 的 IHDR 字段从文件起始偏移 16 处记录宽高。
    if image_format == "png" and len(content) >= 24 and content[12:16] == b"IHDR":
        return struct.unpack(">II", content[16:24])
    # GIF 在逻辑屏幕描述符中用小端整数记录宽高。
    if image_format == "gif" and len(content) >= 10:
        return struct.unpack("<HH", content[6:10])
    # WebP 扩展容器在 VP8X 块中记录宽高减一。
    if image_format == "webp" and len(content) >= 30 and content[12:16] == b"VP8X":
        return (
            1 + int.from_bytes(content[24:27], "little"),
            1 + int.from_bytes(content[27:30], "little"),
        )
    # WebP 无损块使用 14 位宽高字段；有损块另用 VP8 frame header。
    if image_format == "webp" and len(content) >= 25 and content[12:16] == b"VP8L":
        packed = int.from_bytes(content[21:25], "little")
        return (1 + (packed & 0x3FFF), 1 + ((packed >> 14) & 0x3FFF))
    # WebP VP8 有损块在帧起始码之后用 14 位宽高字段。
    if image_format == "webp" and len(content) >= 30 and content[12:16] == b"VP8 ":
        start = 20
        if content[start + 3 : start + 6] == b"\x9d\x01\x2a":
            return (
                int.from_bytes(content[start + 6 : start + 8], "little") & 0x3FFF,
                int.from_bytes(content[start + 8 : start + 10], "little") & 0x3FFF,
            )
    # JPEG 的宽高在 SOF 段；按长度跳过其他 marker 段，避免在压缩数据中误匹配。
    if image_format == "jpeg":
        offset = 2
        while offset + 4 <= len(content):
            # SOI 后的段以 FF marker 起始，格式不完整时不猜测尺寸。
            if content[offset] != 0xFF:
                return None
            while offset < len(content) and content[offset] == 0xFF:
                offset += 1
            if offset >= len(content):
                return None
            marker = content[offset]
            offset += 1
            # SOS 开始扫描压缩数据，宽高若仍未找到就返回未知。
            if marker == 0xDA:
                return None
            # 无长度的独立 marker 无需读取后续段长。
            if marker == 0x01 or 0xD0 <= marker <= 0xD9:
                continue
            if offset + 2 > len(content):
                return None
            segment_length = int.from_bytes(content[offset : offset + 2], "big")
            # 非法段长会导致死循环或越界，立即停止解析。
            if segment_length < 2 or offset + segment_length > len(content):
                return None
            # 排除不含尺寸的 DHT、JPG 和 DAC marker，仅解析 SOF 类别。
            if marker in (0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF) and segment_length >= 7:
                return (
                    int.from_bytes(content[offset + 5 : offset + 7], "big"),
                    int.from_bytes(content[offset + 3 : offset + 5], "big"),
                )
            offset += segment_length
    return None


def target_path(output: Path, index: int, total: int, extension: str) -> Path:
    """计算单张图片路径；输入基础路径、序号、总数和扩展名，返回不会误标格式的最终路径。"""
    candidate = output.expanduser().resolve()
    # 多图结果通过稳定编号避免覆盖同一个输出文件。
    if total > 1:
        candidate = candidate.with_name(f"{candidate.stem}-{index}{candidate.suffix}")
    # 接口实际格式优先，防止 PNG 字节被误标为 JPEG 等扩展名。
    if candidate.suffix.lower() != extension:
        candidate = candidate.with_suffix(extension)
    return candidate


def write_atomic(path: Path, content: bytes) -> None:
    """原子保存图片；输入最终路径和已校验字节，会创建父目录并避免留下半写文件。"""
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(f".{path.name}.{uuid.uuid4().hex}.tmp")
    try:
        temporary.write_bytes(content)
        os.replace(temporary, path)
    finally:
        # 异常路径仅清理本次创建的临时文件，不触碰已有目标文件。
        if temporary.exists():
            temporary.unlink()


def generate(
    config: dict[str, str],
    prompt: str,
    output: Path,
    size: str,
    count: int,
    timeout: int,
) -> dict[str, Any]:
    """执行一次生图；输入接口配置和生成参数，返回不含图片正文的摘要并把结果写入输出路径。"""
    endpoint = f"{config['base_url']}/images/generations"
    response = request_json(
        endpoint,
        config["api_key"],
        timeout,
        {
            "model": config["model"],
            "prompt": prompt,
            "n": count,
            "size": size,
        },
    )
    data = response.get("data")
    # 生图成功必须至少包含一个 OpenAI 风格的 data 条目。
    if not isinstance(data, list) or not data:
        raise RuntimeError("Upstream response does not contain generated image data")

    decoded: list[tuple[bytes, str, str | None]] = []
    for item in data:
        # 非对象条目无法承载 b64_json 或 URL，直接判定响应不完整。
        if not isinstance(item, dict):
            raise RuntimeError("Upstream returned an invalid image item")
        content = image_bytes(item, config, timeout)
        image_format, _ = detect_format(content)
        revised_prompt = item.get("revised_prompt")
        # revised_prompt 仅在确实为字符串时纳入摘要，避免泄露大块未知结构。
        if not isinstance(revised_prompt, str):
            revised_prompt = None
        decoded.append((content, image_format, revised_prompt))

    files: list[dict[str, Any]] = []
    for index, (content, image_format, revised_prompt) in enumerate(decoded, start=1):
        extension = ".jpg" if image_format == "jpeg" else f".{image_format}"
        path = target_path(output, index, len(decoded), extension)
        write_atomic(path, content)
        dimensions = image_dimensions(content, image_format)
        item_summary: dict[str, Any] = {
            "path": str(path),
            "format": image_format,
            "bytes": len(content),
        }
        # 只在图片头提供可靠信息时汇报像素尺寸，避免把请求值当作实际结果。
        if dimensions is not None:
            item_summary["width"], item_summary["height"] = dimensions
        # 仅当上游提供改写提示词时返回，便于解释实际生成依据。
        if revised_prompt:
            item_summary["revised_prompt"] = revised_prompt
        files.append(item_summary)

    return {
        "ok": True,
        "endpoint": endpoint,
        "model": config["model"],
        "requested_size": size,
        "requested_count": count,
        "returned_count": len(files),
        "files": files,
    }


def parse_args() -> argparse.Namespace:
    """解析命令行参数；返回校验后的连接检查或生图配置，不执行网络和文件副作用。"""
    parser = argparse.ArgumentParser(
        description="Generate images with gpt-image-2.5-flare through DubDub."
    )
    parser.add_argument("--check", action="store_true", help="Check API and model access.")
    parser.add_argument("--prompt", help="Text prompt for image generation.")
    parser.add_argument("--output", type=Path, help="Output path for the generated image.")
    parser.add_argument("--size", default="1024x1024", help="OpenAI image size.")
    parser.add_argument("--count", type=int, default=1, help="Number of images, 1-4.")
    parser.add_argument("--timeout", type=int, default=300, help="Timeout in seconds.")
    args = parser.parse_args()

    # 连接检查不需要提示词和输出路径，避免为了探测而创建文件。
    if args.check:
        # 检查模式与生图参数混用容易让调用意图不清，直接拒绝。
        if args.prompt is not None or args.output is not None:
            parser.error("--check cannot be combined with --prompt or --output")
        return args

    # 正式生图必须同时给出非空提示词和输出路径。
    if not args.prompt or not args.prompt.strip() or args.output is None:
        parser.error("--prompt and --output are required unless --check is used")
    # 数量限制为小批次，避免误操作造成不可控用量。
    if not 1 <= args.count <= 4:
        parser.error("--count must be between 1 and 4")
    # 尺寸只接受 OpenAI 的 auto 或明确宽高格式，拒绝模糊输入。
    if not VALID_SIZE.fullmatch(args.size):
        parser.error("--size must be 'auto' or WIDTHxHEIGHT")
    # 超时必须为正数，零值不能误当成无限等待。
    if args.timeout <= 0:
        parser.error("--timeout must be greater than zero")
    return args


def main() -> int:
    """协调配置、网络请求和输出；成功返回零，失败输出脱敏错误并返回一，不自动重试。"""
    args = parse_args()
    config: dict[str, str] | None = None
    try:
        config = load_config()
        # 检查模式仅验证认证和模型发现，不产生计费生图请求。
        if args.check:
            result = check_connection(config, args.timeout)
            print(json.dumps(result, ensure_ascii=False, indent=2))
            return 0 if result["ok"] else 1

        result = generate(
            config,
            args.prompt.strip(),
            args.output,
            args.size,
            args.count,
            args.timeout,
        )
        print(json.dumps(result, ensure_ascii=False, indent=2))
        return 0
    except (RuntimeError, OSError) as exc:
        message = str(exc)
        # 上游错误文本可能回显请求令牌；交付前统一遮蔽配置中的密钥。
        if config is not None:
            message = message.replace(config["api_key"], "[REDACTED]")
        print(f"error: {message}", file=sys.stderr)
        return 1


# 只有直接执行脚本时才运行网络流程，被导入用于测试时保持无副作用。
if __name__ == "__main__":
    raise SystemExit(main())
